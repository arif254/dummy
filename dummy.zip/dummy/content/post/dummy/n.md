---
title: The rise of the Hyksos
slug: /n/
date: 2019-07-05T15:25:59+06:00
description: Hyksos, dynasty of Palestinian origin that ruled northern Egypt as the 15th dynasty (c. 1630–1523 bce; see ancient Egypt. The Second Intermediate period). The name Hyksos was used by the Egyptian historian Manetho (flourished 300 bce), who, according to the Jewish historian Flavius Josephus (flourished 1st century ce), translated the word as “king-shepherds” or “captive shepherds.” 
---
Hyksos, dynasty of Palestinian origin that ruled northern Egypt as the 15th dynasty (c. 1630–1523 bce; see ancient Egypt: The Second Intermediate period). The name Hyksos was used by the Egyptian historian Manetho (flourished 300 bce), who, according to the Jewish historian Flavius Josephus (flourished 1st century ce), translated the word as “king-shepherds” or “captive shepherds.” 

Josephus himself wished to demonstrate the great antiquity of the Jews and thus identified the Hyksos with the Hebrews of the Bible. Hyksos was in fact probably an Egyptian term for “rulers of foreign lands” (heqa-khase), and it almost certainly designated the foreign dynasts rather than an ethnic group. Modern scholarship has identified most of the Hyksos kings’ names as Semitic.

The rise of the Hyksos kings in Egypt was made possible by an influx of immigrants from Palestine into Egypt beginning about the 18th century bce. The immigrants brought with them new technologies, including the horse and chariot, the compound bow, and improved metal weapons. 

Most of them settled in the eastern portion of the Nile Delta, where they achieved a dominant role in trade with western Asia. Archaeological excavations in that area have revealed a Canaanite-style temple, Palestinian-type burials (including horse burials), Palestinian types of pottery, quantities of their superior weapons, and a series of Minoan frescoes that demonstrate stylistic parallels to those of Knossos and Thera. 

The most-prominent settlement was Avaris (modern Tall al-Dabʿa), a fortified camp over the remains of a Middle Kingdom town in the northeastern delta. Their chief deity was the Egyptian storm and desert god, Seth, whom they identified with a Syrian storm god, Hadad.